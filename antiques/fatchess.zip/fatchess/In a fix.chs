FatChess SaveGame file
(c) Chris Hulbert 1999

WhoseTurn = White
WhiteType = Human
BlackType = Computer

BoardRow1 = r..k...r
BoardRow2 = pp...pp.
BoardRow3 = .bn.b..p
BoardRow4 = ..N.....
BoardRow5 = P.......
BoardRow6 = ..P.P...
BoardRow7 = .P....PP
BoardRow8 = R.B.K..R