FatChess SaveGame file
(c) Chris Hulbert 1999

WhoseTurn = White
WhiteType = Human
BlackType = Computer

BoardRow1 = rnbqkbnr
BoardRow2 = ...pp..q
BoardRow3 = Q.......
BoardRow4 = .......q
BoardRow5 = Q.......
BoardRow6 = .......q
BoardRow7 = Q..PP...
BoardRow8 = RNBQKBNR