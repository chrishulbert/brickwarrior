FatChess SaveGame file
(c) Chris Hulbert 1999

WhoseTurn = White
WhiteType = Human
BlackType = Computer

BoardRow1 = K.......
BoardRow2 = R.......
BoardRow3 = R.......
BoardRow4 = R.......
BoardRow5 = .......r
BoardRow6 = .......r
BoardRow7 = .......r
BoardRow8 = .......k